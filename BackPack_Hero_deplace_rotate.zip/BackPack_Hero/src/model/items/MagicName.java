package model.items;

public enum MagicName {
	UnstableManaStone, manaSone, largeManaStone, blackManaStone, book, wand
}
