package model.items;

public enum ShieldName {
	RoughBuckler, SlatsShield, KnightsShield

}
