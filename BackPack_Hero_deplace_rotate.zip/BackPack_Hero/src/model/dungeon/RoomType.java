package model.dungeon;

public enum RoomType {
	EMPTY, ENTRANCE, EXIT, ENEMY, TREASURE, MERCHANT, HEALER
}
