package model.items;

public enum WeaponName {
	woodenSword, dagger, machete, chipppedSword, doru, bowblade,

}
