package model.items;

public enum ArmorName {
	RoughBuckler, KnightsShield, ironHelmet, spikedHelmet, bronzeBreastplate, tunic, leftGlove, rightGlove, leatherBoots,
	steelBoots, brick, brickwall

}
