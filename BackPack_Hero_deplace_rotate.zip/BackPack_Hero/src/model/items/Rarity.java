package model.items;

public enum Rarity {
	commun, uncommun, rare, legendary

}
